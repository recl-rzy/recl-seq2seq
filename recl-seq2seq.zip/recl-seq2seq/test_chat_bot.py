import config
import pickle
from chatbot.word_sequence import Word_Sequence
from chatbot.dataset import train_data_loader
from chatbot.train import train

def save_ws():
    ws = Word_Sequence()
    for line in open(config.chatbot_input_path, encoding="utf-8").readlines():
        ws.fit(line.strip().split())
    ws.build_vocad()
    print(len(ws))
    pickle.dump(ws, open(config.chatbot_ws_input_path, "wb"))

    ws = Word_Sequence()
    for line in open(config.chatbot_target_path, encoding="utf-8").readlines():
        ws.fit(line.strip().split())
    ws.build_vocad()
    print(len(ws))
    pickle.dump(ws, open(config.chatbot_ws_target_path, "wb"))

def test_data_loader():
    for index, (input, target, input_length, target_length) in enumerate(train_data_loader):
        print(index)
        print(input)
        print(target)
        print(input_length)
        print(target_length)
        print(input.size())
        print(target.size())
        break

def train_seq2seq():
     for i in range(6):
         train(i)

if __name__=="__main__":
    train_seq2seq()
    # save_ws()
    #test_data_loader()
