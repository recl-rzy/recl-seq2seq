from prepare_corpus.prepare_user_dict.test_user_dict import test_user_dict
from lib.cut_sentence import cut

if __name__=="__main__":
    # test_user_dict()

    str = "python好难啊1!"
    print(cut(str, use_stopwords=True))