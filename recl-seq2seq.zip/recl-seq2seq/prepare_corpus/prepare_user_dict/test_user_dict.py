"""
测试词典
"""
import jieba
import config

jieba.load_userdict(config.user_dict_path)

def test_user_dict():
    sentence = "python和c++哪个难"
    ret = jieba.lcut(sentence)
    print(ret)