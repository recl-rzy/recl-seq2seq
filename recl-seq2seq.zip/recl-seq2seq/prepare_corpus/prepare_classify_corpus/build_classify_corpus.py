import pandas
from lib.cut_sentence import cut
import config
import json

# 闲聊语料(小黄鸡语料)
xiaohunagji_path = r".\corpus\classify\origin_corpus\xiaohuangji50w_nofenci.conv"

# 问答的语料

def keywords_in_line(line):
    # 判断不符合要求的词语
    keywords_list = ['救命啊', '可怕']
    for word in keywords_list:
        if word in keywords_list:
            return True
        else:
            return False

def process_xiaohunagji(file):
    """处理小黄鸡语料"""
    flag = 0
    for line in open(xiaohunagji_path, encoding="utf-8").readlines():
        if line.startswith("E"):
            flag = 0
            continue
        elif line.startswith("M"):
            if flag == 0:
                line = line[1:].strip()
                flag = 1
            else:
                continue
        line_cuted = cut(line)
        if keywords_in_line(line_cuted):
            line_cuted = " ".join(line_cuted) + '\t' + "__label__chat"
            file.write(line_cuted + '\n')

def process_byhand_data(file):
    """处理手动收集的数据"""
    total_lines = json.loads(open(config.byhand_path).read())
    for key in total_lines:
        for lines in total_lines[key]:
            for line in lines:
                line_cuted = cut(line)
                line_cuted = " ".join(line_cuted) + "\t" + "__label__QA"
                file.write(line_cuted + "\n")

def process_crawled_data(file):
    """处理csv文件"""
    for line in open(config.byhand_path).readlines():
        line_cuted = cut(line)
        line_cuted = " ".join(line_cuted) + '\t' + "__label__QA"
        file.write(line_cuted + '\n')

def process():
    print(123131)
    f = open(config.classify_corpus_path, "a", encoding="utf-8")
    # 处理小黄鸡
    process_xiaohunagji(f)
    # 处理手动构造的数据
    process_byhand_data(f)
    # 文件关闭
    f.close()