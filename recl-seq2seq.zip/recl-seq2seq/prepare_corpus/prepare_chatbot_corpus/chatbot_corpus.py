"""
机器人闲聊语料
"""
from lib.cut_sentence import cut
from tqdm import tqdm
import config

def filters(one_pair_qa):
    "TODO 语料过滤"
    if len(one_pair_qa[0][0].strip()) == 0 or len(one_pair_qa[1][0].strip()) == 0:
        return True

def prepare_xiaohuangji(by_word=False):
    """
    :param by_word: 是否按词切分
    :return: None
    """
    # 问答对数量
    one_pair_len = 0
    # 保存当前问答对
    one_pair_qa = []
    path = r".\..\corpus\classify\origin_corpus\xiaohuangji50w_nofenci.conv"
    input_path = config.chatbot_input_path
    target_path = config.chatbot_target_path
    f_input = open(input_path, "a", encoding="utf-8")
    f_target = open(target_path, "a", encoding="utf-8")
    for line in tqdm(open(path, encoding="utf-8").readlines(), ascii=True, desc="处理小黄鸡语料"):
        if line.startswith("E"):
            continue
        else:
            line = line[1:].strip().lower()
            line_cuted = cut(line, by_word=by_word)
            line_cuted = " ".join(line_cuted)
            if len(one_pair_qa) < 2:
                one_pair_qa.append([line_cuted, line])
            if len(one_pair_qa) == 2:
                if filters(one_pair_qa):
                    one_pair_qa = []
                    continue
                f_input.write(one_pair_qa[0][0] + '\n')
                f_target.write(one_pair_qa[1][0] + '\n')
                one_pair_qa = []
                one_pair_len += 1
    print("写入: ", one_pair_len)
    # 关闭文件
    f_input.close()
    f_target.close()

def prepare_qingyun(by_word=False):
    # 问答对数量
    one_pair_len = 0
    path = r"C:\chat_qingyun\corpus\classify\origin_corpus\qingyun.tsv"
    input_path = config.chatbot_input_path
    target_path = config.chatbot_target_path
    f_input = open(input_path, "a", encoding="utf-8")
    f_target = open(target_path, "a", encoding="utf-8")
    for line in tqdm(open(path, encoding="utf-8").readlines(), ascii=True, desc="处理青云语料"):
        line = list(line.lower().split())
        q = cut(line[0], by_word=by_word)
        a = cut(line[1], by_word=by_word)
        q = " ".join(q)
        a = " ".join(a)
        f_input.write(q + '\n')
        f_target.write(a + '\n')
        one_pair_len += 1
    print("写入: ", one_pair_len)
    # 关闭文件
    f_input.close()
    f_target.close()
