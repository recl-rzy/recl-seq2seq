from classify.build_model import build_classify_model, get_classify_model

if __name__ == "__main__":
    build_classify_model()