"""
分词
"""
import jieba
import config
import string
import jieba.posseg as psg
from lib.get_stopwords_dict import stopwords
import logging

jieba.setLogLevel(logging.INFO)
jieba.load_userdict(config.user_dict_path)
# 英文准备
letters = string.ascii_lowercase + "+"

def cut_sentence_by_word(sentence):
    """中英文分词"""
    result = []
    temp = ""
    for word in sentence:
        if word.lower() in letters: # 判断是否为英文
            temp += word
        else:                       # 判断是否是汉字
            if temp != "":
                result.append(temp.lower())
                temp = ""
            result.append(word.strip())
    if temp != "":
        result.append(temp.lower())
    return result

def cut(sentence, by_word=False, use_stopwords=False, with_sg=False):
    """
    :param sentence: 分词句子
    :param by_word: 是否按字切分
    :param user_stopwords: 是否使用停用词
    :param with_sg: 是否返回词性
    :return:
    """
    if by_word:
        result = cut_sentence_by_word(sentence)
    else:
        result = psg.lcut(sentence)
        result = [(i.word, i.flag) for i in result]
        if not with_sg:
            result = [i[0] for i in result]

    # 判断是否使用停用词
    # 判断是否使用停用词
    if use_stopwords:
        result = [i for i in result if i not in stopwords]
    return result





if __name__=="__main__":
    a = "pyhthon和c++谁更难一起"
    print(cut(a, by_word=True))
    print(cut(a, by_word=False))