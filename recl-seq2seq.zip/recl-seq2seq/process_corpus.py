from prepare_corpus.prepare_chatbot_corpus.chatbot_corpus import prepare_qingyun
import config

if __name__ == "__main__":
    # process()
    prepare_qingyun(by_word=config.chatbot_by_word)