
class Word_Sequence:
    PAD_TAG = "PAD"  # 填充词
    UNK_TAG = "UNK"  # 未知词
    SOS_TAG = "SOS"  # 开始标志
    EOS_TAG = "EOS"  # 结束标志
    PAD = 0
    UNK = 1
    SOS = 2
    EOS = 3

    def __init__(self):
        self.dict = {
            self.PAD_TAG: self.PAD,
            self.UNK_TAG: self.UNK,
            self.SOS_TAG: self.SOS,
            self.EOS_TAG: self.EOS
        }
        self.count = {}
        self.inverse_dict = {}

    def fit(self, sentence):
        """
        传入句子，统计词频
        :param sentence: []列表
        :return:
        """
        for word in sentence:
            self.count[word] = self.count.get(word, 0) + 1

    def build_vocad(self, min_count=2, max_count=None, max_feature=None):
        """
        构造词典
        :param min_count: 最小词频
        :param max_count: 最大词频
        :param max_features:
        :return:
        """
        temp = self.count.copy()
        for key in temp:
            cur_count = self.count.get(key, 0)
            if min_count is None:
                if cur_count < min_count:
                    del self.count[key]
            if max_count is not None:
                if cur_count > max_count:
                    del self.count[key]
        if max_feature is not None:
            self.count = dict(sorted(self.count.items(), key=lambda x: x[1], reverse=True)[:max_feature])
        for key in self.count:
            self.dict[key] = len(self.dict)
        self.inverse_dict = dict(zip(self.dict.values(), self.dict.keys())) # 键值对互换{词编号 : 词}

    def transform(self, sentence, max_len, add_eos=False):
        """
        将sentence转为数字序列
        :param sentence: []
        :param max_len: 序列最大长度
        :param add_eos: 是否添加结束符
        :return:
        """
        if len(sentence) > max_len:
            sentence = sentence[:max_len]
        sentence_len = len(sentence)

        if add_eos:
            sentence = sentence + [self.EOS_TAG]
        if sentence_len < max_len:
            sentence = sentence + [self.PAD_TAG] * (max_len - sentence_len)
        result = [self.dict.get(i, self.UNK) for i in sentence]
        return result

    def inverse_transform(self, indices):
        """序列转句子"""
        result = []
        for index in indices:
            if index == self.EOS:
                break
            result.append(self.inverse_dict.get(index, self.UNK_TAG))
        return result

    def __len__(self):
        return len(self.dict)
