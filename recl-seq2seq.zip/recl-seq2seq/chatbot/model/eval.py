from chatbot.seq2seq import Seq2Seq
import config
from tqdm import tqdm
import torch
from chatbot.word_sequence import Word_Sequence
from lib.cut_sentence import cut
import numpy as np
from chatbot.model.decoder import Decoder
from chatbot.model.encoder import Encoder

encoder = Encoder()
decoder = Decoder()
seq2seq = Seq2Seq(encoder, decoder)
print(seq2seq.load_state_dict(torch.load(config.chatbot_model_load_path)))

while True:
    str = input("输入：")
    str = cut(str, by_word=False)
    str = config.chatbot_ws_input.transform(str, max_len=config.chatbot_input_max_len)
    str_length = torch.LongTensor([len(str)])
    str = torch.LongTensor([str])

    indices = seq2seq.evaluate(str, str_length)
    indices = np.array(indices).transpose()

    indices = indices[0]
    print(indices)
    result = []

    temp_result = config.chatbot_ws_target.inverse_transform(indices)
    print(">>>" + "".join(temp_result))






