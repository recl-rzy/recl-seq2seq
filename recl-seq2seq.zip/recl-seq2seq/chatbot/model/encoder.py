"""
编码器
"""

import torch.nn as nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
import config

class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        self.embedding = nn.Embedding(num_embeddings=len(config.chatbot_ws_input),
                                      embedding_dim=config.chatbot_embedding_dim,
                                      padding_idx=config.chatbot_ws_input.PAD)
        self.gru = nn.GRU(input_size=config.chatbot_embedding_dim,
                          num_layers=config.chatbot_encoder_num_layers,
                          hidden_size=config.chatbot_encoder_hidden_size,
                          batch_first=True)
    def forward(self, input, input_length):
        """
        前馈
        :param input: [batch_size, max_len]
        :param input_length:
        :return:
        """
        embeded = self.embedding(input)    # [batch_size, max_len, embedding_dim]
        embeded = pack_padded_sequence(embeded, input_length, batch_first=True) # 打包
        out, hidden = self.gru(embeded)

        # 解包
        out, out_length = pad_packed_sequence(out, batch_first=True, padding_value=config.chatbot_ws_input.PAD)

        # hidden [1*(单层为1，循环为2), batch_size, hidden_size ]
        # out [batch_size, seq_len, hidden_size]
        return out, hidden

