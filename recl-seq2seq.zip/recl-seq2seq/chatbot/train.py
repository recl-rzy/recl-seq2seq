from chatbot.dataset import train_data_loader
from chatbot.seq2seq import Seq2Seq
from torch.optim import Adam
import torch.nn.functional as F
import config
from tqdm import tqdm
import torch
import torch.nn as nn
from chatbot.model.decoder import Decoder
from chatbot.model.encoder import Encoder
import numpy as np

clip = 30.0

encoder = Encoder()
decoder = Decoder()


seq2seq = Seq2Seq(encoder, decoder)
seq2seq.load_state_dict(torch.load(config.chatbot_model_load_path))
encoder_optimizer = Adam(encoder.parameters(), lr=0.0001)
decoder_optimizer = Adam(decoder.parameters(), lr=0.0001)

def train(epoch):
    bar = tqdm(enumerate(train_data_loader), total=len(train_data_loader), ascii=True, desc="Train")
    loss_list = []
    for index, (input, target, input_length, target_length) in bar:
        encoder_optimizer.zero_grad()
        decoder_optimizer.zero_grad()
        decoder_outputs, _ = seq2seq(input, target, input_length, target_length)
        decoder_outputs = decoder_outputs.view(decoder_outputs.size(0)*decoder_outputs.size(1), -1)
        target = target.view(-1)
        loss = F.nll_loss(decoder_outputs, target, ignore_index=config.chatbot_ws_input.PAD)
        loss_list.append(loss.item())

        aver_loss = np.mean(loss_list)
        if index == len(train_data_loader)-2:
            print("模型已保存, 当前损失为: {:.6f}".format(aver_loss))
            torch.save(seq2seq.state_dict(), config.chatbot_model_load_path)

        print("epoch: {}\t index: {}\t loss: {:6f}".format(epoch, index, aver_loss))

        loss.backward()

        _ = nn.utils.clip_grad_norm_(encoder.parameters(), clip)
        _ = nn.utils.clip_grad_norm_(decoder.parameters(), clip)

        decoder_optimizer.step()
        encoder_optimizer.step()
        # bar.set_description("epoch: {}\t index: {}\t loss: {:6f}".format(epoch, index, aver_loss))


