"""配置文件(语料相关)"""
import pickle
import torch


"""语料相关"""
user_dict_path = r"C:\chat_qingyun\corpus\user_dict\user_dict.txt"
stopwords_path = r"C:\chat_qingyun\corpus\user_dict\cn_stopwords.txt"
classify_corpus_path = ".\corpus\classify\classify.txt"
byhand_path = ""

"""分类相关"""
classify_model_path = "./model/classify.model"

"""chatbot"""
chatbot_by_word = False

if chatbot_by_word:
    chatbot_input_path = r".\corpus\chatbot\input_by_word.txt"
    chatbot_target_path = r".\corpus\chatbot\target_by_word.txt"
else:
    chatbot_input_path = r".\corpus\chatbot\input.txt"
    chatbot_target_path = r".\corpus\chatbot\target.txt"

# 词典保存路径
if chatbot_by_word:
    chatbot_ws_input_path = r"C:\chat_qingyun\model\chatbot\ws_by_word_input.pkl"
    chatbot_ws_target_path = r"C:\chat_qingyun\model\chatbot\ws_by_word_target.pkl"
else:
    chatbot_ws_input_path = r"C:\chat_qingyun\model\chatbot\ws_input.pkl"
    chatbot_ws_target_path = r"C:\chat_qingyun\model\chatbot\ws_target.pkl"

# 加载词典
chatbot_ws_input = pickle.load(open(chatbot_ws_input_path, "rb"))
chatbot_ws_target = pickle.load(open(chatbot_ws_target_path, "rb"))


chatbot_batch_size = 128
if chatbot_by_word:
    chatbot_input_max_len = 25
    chatbot_target_max_len = 25
else:
    chatbot_input_max_len = 25
    chatbot_target_max_len = 25

teacher_forcing_ration = 0.5

chatbot_embedding_dim = 256
chatbot_encoder_num_layers = 1
chatbot_encoder_hidden_size = 256

chatbot_decoder_num_layers = 1
chatbot_decoder_hidden_size = 256

chatbot_model_load_path = "C:\chat_qingyun1\model\chatbot\seq2seq2.model" if not chatbot_by_word else "C:\chat_qingyun\model\chatbot\seq2seq_by_word2.model"
chatbot_optimizer_save_path = "C:\chat_qingyun\model\chatbot/optimizer1.model" if not chatbot_by_word else "C:\chat_qingyun\model\chatbot/optimizer1.model"

chatbot_model_save_path = "C:\chat_qingyun1\model\chatbot\seq2seq1.model"